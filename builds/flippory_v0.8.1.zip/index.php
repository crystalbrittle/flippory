<?php
header("Location: https://bludgeonsoft.org/flippory/index.html");
die();
?>